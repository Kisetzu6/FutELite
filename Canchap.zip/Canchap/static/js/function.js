document.addEventListener('DOMContentLoaded', function () {
        const reservasLink = document.getElementById('reservasLink');
        if (reservasLink) {
            reservasLink.addEventListener('click', function (event) {
                event.preventDefault();
                const isLoggedIn = localStorage.getItem('isLoggedIn');
                if (isLoggedIn === 'true') {
                    window.location.href = '/reservas';
                } else {
                    alert('Debes iniciar sesión para acceder a las reservas.');
                    window.location.href = '/login';
                }
            });
        }
    });

localStorage.removeItem('isLoggedIn');