from flask import Flask, render_template, request, redirect
import pandas as pd
import matplotlib.pyplot as plt
import io
import base64
usuarios = {"jero": "22", "davison": "en4", "diome": "23"}
user = None
email = None
tipo = None
id = 1
reserva = None
usuarios_reservas = {}

app = Flask(__name__)
@app.route("/", methods=["GET", "POST"])
def home():
    return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    global usuarios
    global user
    mensaje_acceso = None
    user = None
    contra = None
    Errores =None
    mensaje_denegado =None
    acceso = None
    if request.method == "POST":
        try:
            user = request.form["user"].strip()
            contra = request.form["contra"].strip()
            if user in usuarios and contra == usuarios[user]:
                mensaje_acceso = f"Bienvenido, {user}. Haz accedido correctamente."
                acceso = True
                return redirect('/reservas')

            else:
                mensaje_denegado = f"Acceso Restringido, Datos incorrectos"
                acceso = False

        except Exception:
            Errores = "Ingrese correctamente los datos (Usuario o Contraseña)."

    return render_template(
        "login.html",
        Errores=Errores,
        user=user,
        contra=contra,
        mensaje_acceso=mensaje_acceso,
        mensaje_denegado=mensaje_denegado,
        acceso = acceso
    )

@app.route('/contacto')
def contacto():
    return render_template('contactanos.html')

@app.route("/registro", methods = ["GET","POST"])
def Registro():
    global usuarios
    global user
    mensaje_acceso = None
    contra = None
    correo = None
    Errores =None
    mensaje_denegado =None
    acceso = None
    if request.method == "POST":
        try:
            user = request.form["user"].strip()
            contra = request.form["contra"].strip()
            if user is not usuarios:
                usuarios[user] = contra 
                mensaje_acceso = f"Bienvenido, {user}. Haz sido Registrado correctamente."
                acceso = True
            else:
                mensaje_denegado = f"Acceso Restringido, Datos incorrectos"
                acceso = False

        except Exception:
            Errores = "Ingrese correctamente los datos (Usuario o Contraseña)."

    return render_template(
        "registro.html",
        Errores=Errores,
        user=user,
        contra=contra,
        mensaje_acceso=mensaje_acceso,
        mensaje_denegado=mensaje_denegado,
        correo = correo,
        acceso = acceso
    )

@app.route('/reservas', methods=['GET', 'POST'])
def crear_reserva():
    global user
    global id
    grafico_base64 = None
    if request.method == 'POST':
        user = request.form.get('user')
        email = request.form.get('email')
        reserva = request.form.get('reserva')
        tipo = request.form.get('tipo_de_cancha')

        usuarios_reservas[id] = {
            'user':user,
            'email': email,
            'reserva': reserva,
            'tipo': tipo
        }
        id = id + 1
        
        df=pd.read_csv('canchas.csv', sep=';')
        #convierte los numeros que hay en N°de canchas de csv a formato int en python
        df['N.º de canchas']=pd.to_numeric(df['N.º de canchas'])
        #funcion que elimina filas que tienen valores nulos
        df = df.dropna(subset=['Canchas Sinteticas Pereira-Dosquebradas', 'N.º de canchas'])
        plt.figure()
        plt.barh(df['Canchas Sinteticas Pereira-Dosquebradas'], df['N.º de canchas'], color='skyblue')
        plt.xlabel('N.º de canchas')
        plt.ylabel('Nombre de la cancha')
        plt.title('Número de canchas por sede en Pereira-Dosquebradas')
        plt.tight_layout()
        img = io.BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        imagen_base64 = base64.b64encode(img.getvalue()).decode()
        plt.close()
        

        grafico_base64 = imagen_base64
    return render_template('reservas.html', usuarios=usuarios_reservas, grafico_base64=grafico_base64)

@app.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar(id):
    usuario = usuarios_reservas.get(id)
    if not usuario:
        return redirect('/reservas')

    if request.method == 'POST':
        # Obtener datos del formulario
        user = request.form['user'].strip()
        email = request.form['email'].strip()
        reserva = request.form['reserva'].strip()
        tipo = request.form.get('tipo_de_cancha', '').strip()

        # Actualizar la reserva
        usuarios_reservas[id] = {
            'user': user,
            'email': email,
            'reserva': reserva,
            'tipo': tipo
        }
        return redirect('/reservas')

    # Para GET, mostrar el formulario con datos actuales
    return render_template('editar.html', id=id, user=usuario)

   #Cambios actualizados de /editar/


@app.route('/eliminar/<int:id>', methods=['GET', 'POST'])
def eliminar(id):
    if id in usuarios_reservas:
        del usuarios_reservas[id]
    return redirect('/reservas')

@app.route('/grafica/<int:id>')
def ver_grafica(id):
    usuario = usuarios_reservas.get(id)
    if not usuario:
        return redirect('/reservas')

    # Ejemplo de datos para graficar (puedes personalizarlo según tu lógica)
    tipos = ['5v5', '8v8', '11v11']
    # Supongamos que cuentas cuántas reservas hay por tipo
    conteo_tipos = [0, 0, 0]
    for reserva in usuarios_reservas.values():
        if reserva['tipo'] == '5v5':
            conteo_tipos[0] += 1
        elif reserva['tipo'] == '8v8':
            conteo_tipos[1] += 1
        elif reserva['tipo'] == '11v11':
            conteo_tipos[2] += 1

    # Crear gráfica de barras
    plt.figure(figsize=(8,4))
    barras = plt.bar(tipos, conteo_tipos, color=['#2a7f2a', '#1e5e1e', '#145214'])
    plt.title(f'Reservas por tipo de cancha - Usuario: {usuario["user"]}')
    plt.xlabel('Tipo de cancha')
    plt.ylabel('Número de reservas')
    plt.ylim(0, max(conteo_tipos)+1)

   
    for barra in barras:
        altura = barra.get_height()
        plt.text(barra.get_x() + barra.get_width()/2, altura + 0.1, str(int(altura)), ha='center', fontsize=10)

    plt.tight_layout()

  
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    grafico_base64 = base64.b64encode(img.getvalue()).decode()
    plt.close()

    return render_template('grafica.html', user=usuario, grafico_base64=grafico_base64)



if __name__ == "__main__":
    app.run(debug=True)
#este esta actualizado

